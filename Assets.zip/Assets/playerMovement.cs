using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerMovement : MonoBehaviour
{
    public ParticleSystem dust;
    public CharacterController2D controller;

    float horizontalMove = 0f;
    private BoxCollider2D coll;
    [SerializeField] Transform groundCheckCollider;
    [SerializeField] bool isGrounded = false;
    const float groundCheckRadius = 0.2f;
    [SerializeField] LayerMask groundLayer;

    public float runSpeed = 40f;
    private Rigidbody2D rb;
    bool jump = false;
    bool crouch = false;
    bool canDoubleJump = false;
    [SerializeField] private float jumpForce = 14f;
    bool flipAnimation = false;

    private float activeMoveSpeed;
    public float dashSpeed;
    public float dashLength = .5f, dashCooldown = 1f;
    private float dashCounter; 
    private float dashCoolCounter;
    private float directionChanged = 1;
    private bool inAir = false;

    private float jumpsRemaining;

 

    private enum MovementState { idle, running, jumping, falling , flipping, crouch }

    private Animator anim;


    private void Start(){
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        coll = GetComponent<BoxCollider2D>();
        jumpsRemaining = 2;
        activeMoveSpeed = 40f;
    }
    // Update is called once per frame
    void Update()
    {
        if(isGrounded && inAir){
            CreateDust();
        }
        
        if(isGrounded){
            flipAnimation = false;
            inAir = false;
            jumpsRemaining = 2;
            
        }
        else{
            inAir = true;
        }

        MovementState state;
        rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y);

        
       horizontalMove = Input.GetAxisRaw("Horizontal") * runSpeed;


       if(Input.GetButtonDown("Crouch"))
       {
            crouch = true;
       }
       else if(Input.GetButtonUp("Crouch"))
       {
              crouch = false;
       }


       if(Input.GetButtonDown("Jump"))
       {    
            
            if(jumpsRemaining >= 2)
            {
                jump = true;

                rb.velocity = new Vector2(rb.velocity.x, jumpForce);
                CreateDust();
                canDoubleJump = false;
                --jumpsRemaining;
            }
            else{

                if(jumpsRemaining == 1)
                {
                    jump = true;

                    rb.velocity = new Vector2(rb.velocity.x, jumpForce);
                    CreateDust();
                    canDoubleJump = false;
                    flipAnimation = true;
                    --jumpsRemaining;
                }
            }
            Debug.Log(jumpsRemaining);
       }




       if(horizontalMove > 0 && directionChanged == -1 && isGrounded){
            CreateDust();
       }
       if(horizontalMove < 0 && directionChanged == 1 && isGrounded){
            CreateDust();
       }

       if(Input.GetAxisRaw("Horizontal") == 0){  
           state = MovementState.idle;
       }
       else{
           state = MovementState.running;
       }
       if(crouch){
              state = MovementState.crouch;
       }

       if(rb.velocity.y > .1f){
           state = MovementState.jumping;
           
       }
       else if(rb.velocity.y < -.1f){
           state = MovementState.falling;
       }

       if(flipAnimation){
           state = MovementState.flipping;
       }

       anim.SetInteger("state",(int)state);
       if(horizontalMove > 0 ){
              directionChanged = 1;
       }
       else if(horizontalMove < 0){
              directionChanged = -1;
       }

    }


    void CreateDust()
    {
    dust.Play();
    }


    void GroundCheck(){
        isGrounded = false;
        //check if groundCheck obj is colliding with other 2d colliders like ground
        Collider2D[] colliders = Physics2D.OverlapCircleAll(groundCheckCollider.position, groundCheckRadius, groundLayer );
        if(colliders.Length > 0){
            //grounded
            isGrounded = true;
        } 
    }

    void FixedUpdate(){
        //move player
        GroundCheck();
        controller.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump);

        jump = false;
    }
   // private bool IsGrounded(){
    //    float extraHeightText = .01f;
    //    RaycastHit2D raycastHit = Physics2D.Raycast(boxCollider2d.bounds.center, Vector2.down, boxCollider2d.bounds.extents.y + extraHeightText);
    //    Color rayColor;
    //    if(raycastHit.collider != null){
    //        rayColor = Color.green;
    //    }
    //    else{
    //        rayColor = Color.red;
    //    }
    //    Debug.DrawRay(boxCollider2d.bounds.center, Vector2.down * (boxCollider2d.bounds.extents.y + extraHeightText));
    //    return raycastHit.collider != null;
//
   //}
}



